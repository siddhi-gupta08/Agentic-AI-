import logging
import warnings

# Suppress the LangChain deprecation warning
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Suppress internal PDF parsing warnings
logging.getLogger("pypdf").setLevel(logging.ERROR)

from langchain_community.document_loaders import PyMuPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Suppress internal PDF parsing warnings to keep your terminal clean
logging.getLogger("pypdf").setLevel(logging.ERROR)

# 1. Load the local documents
pdf_files = [
    "Technical_Report.pdf",
    "indira.pdf",
    
]

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50
)

documents = []
for pdf_file in pdf_files:
    # PyMuPDF is much faster and handles bad hex encodings well
    loader = PyMuPDFLoader(pdf_file)
    documents.extend(loader.load())

print(f"Successfully loaded {len(documents)} pages/documents.")
chunks = text_splitter.split_documents(documents)
print(f"Total chunks created: {len(chunks)}")



from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma

# 1.Initialize local embedding model via Olama
embeddings = OllamaEmbeddings(model="qwen3-embedding:0.6b")

# 2. Store embeddings locally on disk

vector_store = Chroma.from_documents(
    documents= chunks,
    embedding=embeddings,
    persist_directory="./chroma_db"
)

print("Vector database created and persisted locally")