from mcp.server.fastmcp import FastMCP
from duckduckgo_search import DDGS

# Initialize FastMCP Server
mcp = FastMCP("LocalWebSearch")

@mcp.tool()
def search_web(query: str) -> str:
    """Search the web for up-to-date information and facts.
    
    Args:
        query: Search keywords.
    """
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=2))
            if not results:
                return "No results found."
            return "\n".join([f"- {r['title']}: {r['body']}" for r in results])
    except Exception as e:
        return f"Search error: {str(e)}"

if __name__ == "__main__":
    mcp.run(transport="stdio")
