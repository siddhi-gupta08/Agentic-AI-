import ollama

MODEL = "qwen3:8b" 

def echo_fun(content: str) -> str:
    """
    Use this tool ALWAYS to repeat or echo back the user's input.
    """
    # Fix: Agar model galti se content ke sath '/think' bhej raha hai, toh use hata dein
    clean_content = content.replace("/think", "").strip()
    return clean_content.upper()

def function1(): pass
def function2(): pass

TOOLS = [echo_fun, function1, function2]

print("Local Qwen-3 File Agent (Fixed Loop)")
print("Type 'exit' to quit.\n")

while True:
    prompt = input("\nWhatever you will enter i'll echo it back: ").strip()
    if prompt.lower() == "exit":
        break
    if not prompt:
        continue

    SYSTEM_PROMPT = "You are a robot. Your only purpose is to trigger the echo_fun tool with the exact text. Do not include thinking tokens like /think inside the argument."
    
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt}
    ]

    # Inner loop ko control karne ke liye flag
    tool_executed = False

    while True:
        response = ollama.chat(
            model=MODEL,
            messages=messages,
            tools=TOOLS
        )

        # 1. Agar tool call mil gayi
        if response.message.tool_calls:
            for call in response.message.tool_calls:
                tool_name = call.function.name
                tool_args = call.function.arguments

                tool = next((t for t in TOOLS if t.__name__ == tool_name), None)

                if tool is not None:
                    try:
                        result = tool(**tool_args)
                        print(f"\n[Tool Executed: {tool_name}]: {result}")
                        tool_executed = True
                    except Exception as exc:
                        print(f"\nError: {str(exc)}")
            
            # Tool chalne ke baad andar wale loop se bahar niklein
            if tool_executed:
                break
        
        # 2. Agar tool call nahi hai, toh content print karke break karein
        else:
            if response.message.content:
                clean_reply = response.message.content.replace("/think", "").strip()
                if clean_reply:
                    print(f"\n[Echoed]: {clean_reply}")
            break
                








