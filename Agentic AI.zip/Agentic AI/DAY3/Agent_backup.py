import json
import os
import subprocess
import psutil
from groq import Groq 

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

#use a free tier model on groq with native tool-calling capabilities
MODEL_NAME = "qwen/qwen3.8-27b"

def echo_fun(content: str):
    return content
TOOLS = [echo_fun]
SYSTEM_PROMPT = """You are a local echo management assistant.
Use the available tools to create , rename , delete and list files.
"""
def run_agent():
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    print("local Qwen3 File Agent")
    print("Type 'exit' to quit.")
    while True:
            prompt= input("\nEnter message to be echoed: ").strip()
            if prompt.lower() == "exit":
                break
            if not prompt:
                continue
    
            messages.append({"role": "user", "content": prompt})

    while True:
        response = client.chat.completions.create(
          model=MODEL_NAME,
          messages=messages,
          tools=TOOLS,
        )
        messages.append(response.message)
        
        if not response.message.tool_calls:
                        print("\nAgent:", response.message.content)
                        break
        
        for call in response.message.tool_calls:
                        name = call.function.name
                        args = call.function.arguments
        
                        tool = next(
                            (t for t in TOOLS if t.__name__ == name),
                            None
                        )
        
        if tool is None:
                        result = "Error: Unknown tool."
        else:
            try:
                result = tool(**args)
            except Exception as exc:
                result = f"Error: {exc}"
        
        print(f"\n[Tool: {name}]")
        print(result)
        
        messages.append({
                        "role": "tool",
                        "tool_name": name,
                        "content": str(result),
                    })
        
        
if __name__ == "__main__":
            run_agent()

      