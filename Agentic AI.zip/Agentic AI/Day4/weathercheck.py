from langchain.agents import create_agent
from langchain_ollama import ChatOllama

# 1. Define your tool
def get_weather(city: str) -> str:
    """Get weather for a given city."""
    return f"It's always sunny in {city}!"

# 2. Instantiate ChatOllama manually and disable the hidden thinking mode override
llm = ChatOllama(
    model="qwen3:8b",
    extra_body={"think": False}  # FIX: Stops Ollama from formatting tools inside hidden tags
)

# 3. Create the agent with your configured llm instance
agent = create_agent(
    model=llm,
    tools=[get_weather],
    system_prompt="You are a helpful assistant",
)

print("Invoking agent...")

# 4. Run the query
result = agent.invoke(
    {"messages": [{"role": "user", "content": "What's the weather in San Francisco?"}]}
)

# 5. Print the output
print("\nFinal Agent Response:")
print(result["messages"][-1].content)

