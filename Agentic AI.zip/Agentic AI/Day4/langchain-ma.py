# this code is to check the CPU details of computer and laptop 

import json
import subprocess
import psutil
from langchain_core.tools import tool
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_ollama import ChatOllama
from langchain.agents import create_agent

llm = ChatOllama(model="qwen3:8b", reasoning=False)

# ---------- 1. TOOLS ----------
@tool
def get_system_metrics() -> str:
    """Get current CPU, RAM, and Disk metrics of the machine."""
    return json.dumps({
        "cpu_usage_percent": psutil.cpu_percent(interval=1),
        "memory_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage("C:\\").percent,
    })

@tool
def ping_host(hostname: str) -> str:
    """Ping a hostname or IP address to verify connectivity."""
    try:
        res = subprocess.check_output(
            ["ping", "-n", "2", hostname], stderr=subprocess.STDOUT, text=True
        )
        return json.dumps({"status": "success", "raw_output": res.strip()})
    except Exception as err:
        return json.dumps({"status": "error", "message": str(err)})

# ---------- 2. AGENTS ----------
system_agent = create_agent(
    model=llm,
    tools=[get_system_metrics],
    system_prompt="You are a system administration agent. Use tools to check CPU, RAM, or Disk metrics.",
)

network_agent = create_agent(
    model=llm,
    tools=[ping_host],
    system_prompt="You are a network diagnostic agent. Use tools to check network status and ping target hosts.",
)

def run_agent(name, agent, user_query):
    print(f"\n--- [{name}] Activated ---")
    result = agent.invoke({"messages": [{"role": "user", "content": user_query}]})
    print(f"[{name} Final Answer]:")
    print(result["messages"][-1].content)

# ---------- 3. ROUTER ----------
router_prompt = ChatPromptTemplate.from_template(
    """You are a query router. Respond with ONLY ONE word:
- 'SYSTEM' if the query asks about local CPU, disk, memory, or system hardware status.
- 'NETWORK' if the query asks about pinging, network latency, or internet connectivity.
- 'UNKNOWN' if it fits neither.
Query: {query}"""
)
router_chain = router_prompt | llm | StrOutputParser()

def orchestrate_query(user_query):
    
    print(f'USER QUERY: "{user_query}"')
    

    decision = router_chain.invoke({"query": user_query}).strip().upper()

    if "SYSTEM" in decision:
        run_agent("System Health Agent", system_agent, user_query)
    elif "NETWORK" in decision:
        run_agent("Network Agent", network_agent, user_query)
    else:
        print("\n[Router]: Request does not match active agent domains.")

if __name__ == "__main__":
    while True:
        question = input("\nAsk me something (type 'exit' to stop): ")
        if question.lower() == "exit":
            break
        orchestrate_query(question)



