from langchain_groq import ChatGroq

# create Groq LLM
llm =ChatGroq(
    model="qwen/qwen3.8-27b",
    temperature=0 
)

#send question
response = llm.invoke(

    "explain Docker in simple terms "
)

print(response.content)

